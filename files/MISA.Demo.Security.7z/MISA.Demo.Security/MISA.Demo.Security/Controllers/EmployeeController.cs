﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MISA.Demo.Security.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using Dapper.Contrib;

namespace MISA.Demo.Security.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        [HttpGet("paging_temp")]
        public AjaxResult GetPaging1([FromQuery] int draw, [FromQuery(Name = "search[value]")] string searchValue)
        {
            AjaxResult res = new AjaxResult() { Draw = draw };

            using (var conn = Util.SQLConnection.GetConnection())
            {
                var data = conn.Query("SELECT * FROM employee WHERE office='San Francisco' AND first_name like '%" + searchValue + "%'");
                var count = data.Count();
                res.RecordsFiltered = res.RecordsTotal = count;
                res.Data = data;
            }
            return res;
        }
        [HttpGet("paging")]
        public AjaxResult GetPaging2([FromQuery] int draw, [FromQuery(Name = "search[value]")] string searchValue)
        {
            AjaxResult res = new AjaxResult() { Draw = draw };

            using (var conn = Util.SQLConnection.GetConnection())
            {
                var term = "%"+searchValue+"%";
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("first_name", term);
                var data = conn.Query("SELECT * FROM employee WHERE office='San Francisco' AND first_name like @first_name", parameters);
                var count = data.Count();
                res.RecordsFiltered = res.RecordsTotal = count;
                res.Data = data;
            }
            return res;
        }
    }
}
