﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MISA.Demo.Security
{
    public class test
    {
        public void Fake(object a)
        {
            Console.WriteLine("MrSoul");
        }
    }
}
