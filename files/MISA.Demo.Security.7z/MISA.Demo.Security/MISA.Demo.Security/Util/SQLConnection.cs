﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MISA.Demo.Security.Util
{
    public static class SQLConnection
    {
        public static MySqlConnection GetConnection()
        {
            return new MySqlConnection("Server = localhost; Database = example; Uid = root; Pwd = 123456");
        }
    }
}
