﻿$(document).ready(function () {
    $('#example').DataTable({
        "processing": false,
        "serverSide": true,
        "ajax": "../api/employee/paging",
        "columns": [
            { "data": "first_name" },
            { "data": "last_name" },
            { "data": "position" },
            { "data": "office" },
            { "data": "start_date" },
            { "data": "salary" }
        ]
    });
});