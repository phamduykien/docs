﻿using Google.Apis.Auth.OAuth2;
using Google.Apis.Drive.v3;
using Google.Apis.Drive.v3.Data;
using Google.Apis.Services;
using Google.Apis.Util.Store;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {

        UserCredential _credential;
        public Form1()
        {
            InitializeComponent();
        }

        private async void btnLoginGoogle_Click(object sender, EventArgs e)
        {

            if (_credential != null)
            {
                MessageBox.Show("Đã đăng nhập");
            }
            else
            {
                UserCredential credential = await GetCredential();
                MessageBox.Show("Đã đăng nhập");
            }
        }

        private async Task<UserCredential> GetCredential()
        {
            if (_credential == null)
            {
                using (var stream = new FileStream("client_secrets.json", FileMode.Open, FileAccess.Read))
                {
                    _credential = await GoogleWebAuthorizationBroker.AuthorizeAsync(
                        GoogleClientSecrets.Load(stream).Secrets,
                        new[] { DriveService.Scope.Drive },
                        "user", CancellationToken.None, new FileDataStore("D://Drive.AllFile", true));
                }
            }
            return _credential;
        }

        private async void btnUploadFile_Click(object sender, EventArgs e)
        {
            try
            {
                var credential = await GetCredential();

                // Create the service using the client credentials.                

                if (credential != null && credential.UserId != null)
                {
                    var service = new DriveService(new BaseClientService.Initializer()
                    {
                        HttpClientInitializer = credential,
                        ApplicationName = "rclone"
                    });
                    OpenFileDialog dlg = new OpenFileDialog();
                    if (dlg.ShowDialog() == DialogResult.OK)
                    {
                        using (var stream = dlg.OpenFile())
                        {


                            var meta = new Google.Apis.Drive.v3.Data.File();
                            // meta.FileExtension = "xlsx";
                            meta.Name = dlg.SafeFileName;

                            var file = service.Files.Create(meta, stream, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
                            file.ResponseReceived += File_ResponseReceived;
                            file.ProgressChanged += File_ProgressChanged;
                            var task = file.Upload();
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void File_ProgressChanged(Google.Apis.Upload.IUploadProgress obj)
        {
            System.Diagnostics.Debug.WriteLine("Progress changed.");
        }

        private async void File_ResponseReceived(Google.Apis.Drive.v3.Data.File obj)
        {
            System.Diagnostics.Debug.WriteLine("Upload completed " + obj.Id);
            MessageBox.Show("Upload completed!");

            var credential = await GetCredential();
            if (credential != null && credential.UserId != null)
            {
                var fileId = obj.Id;
                var permission = new Permission()
                {
                    Role = "reader",
                    Type = "anyone"
                };
                var permisssions = new List<Permission>() { permission };
                var service = new DriveService(new BaseClientService.Initializer()
                {
                    HttpClientInitializer = credential,
                    ApplicationName = "rclone"
                });

                var per = service.Permissions.Create(permission, fileId);
                var execute = await per.ExecuteAsync();
                var x = 1;
            }
        }
    }
}
