'use strict'
var axios = require('axios').default;
const request = require('request');
var express = require('express');
var router = express.Router();
const https = require('https');


/**
 * Chuyển tiếp sign
 */
router.post('/chain/get_table_rows', function (req, res, next) {

    // const axiosResponse = await axios({
    //     url: serverUrl + req.url,
    //     responseType: 'stream'
    //   })

    // req.pipe(request('https://aw-guard.yeomen.ai/v1/chain/get_table_rows')).on('response', response => {
    //     response.pipe(res);
    // });

    //req.pipe(request('https://aw-guard.yeomen.ai/v1/chain/get_table_rows')).pipe(res);

    // var token = req.headers["x-access-token"];
     var payload = req.body;
    axios.post('https://aw-guard.yeomen.ai/v1/chain/get_table_rows', payload, {
        headers: {           
            "Host": "aw-guard.yeomen.ai",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36",
            "Content-Type": "application/json;charset=UTF-8",
            "Accept": "application/json, text/plain, */*",        
            "Origin": "https://play.alienworlds.io",
            "Referer":"https://play.alienworlds.io",
            "Accept-Encoding": "gzip, deflate, br",
        },
        httpsAgent: new https.Agent({
            rejectUnauthorized: false
        })
    }).then((response) => {
        res.send(response);
    }).catch((err) => {
        console.log(err);
        res.send(err);
    });

});

module.exports = router;