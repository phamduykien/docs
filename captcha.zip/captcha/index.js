const axios = new require("axios");
const puppeteer = require("puppeteer-extra");
function sleep(ms) {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}

// add stealth plugin and use defaults (all evasion techniques)
const StealthPlugin = require("puppeteer-extra-plugin-stealth");
puppeteer.use(StealthPlugin());

const { executablePath } = require("puppeteer");
const proxy = process.argv[2];
if (!proxy) {
  console.error("Must config proxy, exit after 10s");
  setTimeout(() => process.exit(), 10000);
} else {
  //proxy dạng host:port:user:pass
  let arr = proxy.split(":");
  let host, port, username, password;
  if (arr[0]) host = arr[0];
    if (arr[1])  port = arr[1];
	  if (arr[2]) username = arr[2];
	    if (arr[3]) password = arr[3];  

  let args=['--window-size=300,400'];
  if (host && port){
    args.push(`--proxy-server=${host}:${port}`);
  }

  puppeteer
    .launch({
      headless: false,
      executablePath: executablePath(),
      args: args,      
    })
    .then(async (browser) => {
      const pages = await browser.pages();
      const page = pages.length > 0 ? pages[0] : browser.newPage();    
      if (username && password){
        await page.authenticate({
            username: username,
            password: password,
          });
      }      
      await page.goto("https://overline.network/app/auth");
      while (true) {
        try {

            
          await page.waitForFunction(
            'document.getElementsByName("cf-turnstile-response").length>0 && document.getElementsByName("cf-turnstile-response")[0].value'
          );
          const elementValue = await page.$eval(
            "input[name=cf-turnstile-response]",
            (el) => el.value
          );
          //Lấy được thì đẩy lên kho, chạy tiếp vòng 2
          const captchaQueueItem = {
            ResolveText: elementValue,
            ResolveDate: new Date(),
          };
          axios
            .post("http://db2.vnwax.com/api/captcha/cf", captchaQueueItem)
            .then((response) => {
              console.log("Success post to queue");
            })
            .catch((error) => {
              console.error(error);
            });
          console.log("success resolve captcha. Wait for next");
        } catch (error) {
          console.error(error);
          await sleep(3000);
        } finally {
          
        }

        await page.reload();
      }

      // await page.waitForSelector("input[type=password]");
      // await page.type("input[type=email]", "mine4l326@quatao.shop");
      // await page.type("input[type=password]", "Chiakhoaso1@");
      // await page.waitForTimeout(1000);
      // const [button] = await page.$x("//button[contains(., 'Sign In')]");
      // if (button) {
      //     await button.click();
      // }
      // await page.waitForTimeout(10000);
      // const localStorageData = await page.evaluate(() => {
      //     let json = {};
      //     for (let i = 0; i < localStorage.length; i++) {
      //         const key = localStorage.key(i);
      //         json[key] = localStorage.getItem(key);
      //     }
      //     return json;
      // });
      // console.log(localStorageData);

      //await browser.close();
    });
}
