﻿//Timepicker
//Copy and modified by PDKIEN 16/03/2022
(function ($) {
  "use strict";
  $.fn.timePicker = function (options) {
    var settings = $.extend(
      {
        selectData: "now",
        timeFormat: "HH:mm",
        locale: "en",
        positionShift: { top: 34, left: 0 },
        title: "Chọn giờ",
      },
      options
    );
    moment.locale(settings.locale);
    var elem = this;
    var limitation = { hour: 23, minute: 59 };
    var mousedown = false;
    var timeout = 800;
    var selectTime = moment();
    var lastSelected = copyDate(selectTime);

    var maskBehavior = function (val) {
      val = val.split(":");
      return parseInt(val[0]) > 19 ? "HZ:M0" : "H0:M0";
    };

    var spOptions = {
      onKeyPress: function (val, e, field, options) {
        field.mask(maskBehavior.apply({}, arguments), options);
      },
      translation: {
        H: { pattern: /[0-2]/, optional: false },
        Z: { pattern: /[0-3]/, optional: false },
        M: { pattern: /[0-5]/, optional: false },
      },
    };

    return this.each(function () {
      elem.addClass("dtp_main");
      updateMainElemGlobal();
      function updateMainElemGlobal() {
        var $s = $("<input>");
        $s.addClass("time-picker-input");
        $s.mask(maskBehavior, spOptions);
        $s.val(selectTime.format(settings.timeFormat));
        elem.append($s);
        $s = $("<i>");
        $s.on("click", buildContent);
        $s.addClass("fa fa-clock-o ico-size");
        elem.append($s);
      }

      function buildContent() {
        var $win = $("<div>");
        $win.addClass("dtp_modal-win");
        var $body = $("body");
        $body.append($win);
        var $content = createContent();
        $body.append($content);
        var offset = elem.offset();
        $content.css({
          top: offset.top + settings.positionShift.top + "px",
          left: offset.left + settings.positionShift.left + "px",
        });

        $win.on("click", function () {
          $content.remove();
          $win.remove();
        });

        attachChangeTime();
        var $fieldTime = $("#field-time");
        var $hour = $fieldTime.find("#d-hh");
        var $minute = $fieldTime.find("#d-mm");

        function attachChangeTime() {
          var $angles = $($content).find('i[id^="angle-"]');
          // $angles.bind('click', changeTime);
          $angles.bind("mouseup", function () {
            mousedown = false;
            timeout = 800;
          });
          $angles.bind("mousedown", function () {
            mousedown = true;
            changeTime(this);
          });
        }

        function changeTime(el) {
          var $el = this || el;
          $el = $($el);
          ///angle-up-hour angle-up-minute angle-down-hour angle-down-minute
          var arr = $el.attr("id").split("-");
          var increment = 1;
          if (arr[1] == "down") {
            increment = -1;
          }
          appendIncrement(arr[2], increment);
         
        }

        function appendIncrement(typeDigits, increment) {
          var $i = typeDigits == "hour" ? $hour : $minute;
          var val = parseInt($i.text()) + increment;
          if (val < 0) {
            val = limitation[typeDigits];
          } else if (val > limitation[typeDigits]) {
            val = 0;
          }
          $i.text(formatDigits(val));
          //Cập nhật lên input
          updateTime();
        }

        function formatDigits(val) {
          if (val < 10) {
            return "0" + val;
          }
          return val;
        }

        function createTimer() {
          var $div = $("<div>");
          $div.addClass("dtp_modal-time-mechanic");
          var $panel = $("<div>");
          $panel.addClass("dtp_modal-append");
          var $i = $("<i>");
          $i.attr("id", "angle-up-hour");
          $i.addClass("fa fa-angle-up ico-size-large cursorily hov");
          $panel.append($i);
          var $m = $("<span>");
          $m.addClass("dtp_modal-midle");
          $panel.append($m);
          $i = $("<i>");
          $i.attr("id", "angle-up-minute");
          $i.addClass("fa fa-angle-up ico-size-large cursorily hov");
          $panel.append($i);
          $div.append($panel);

          $panel = $("<div>");
          $panel.addClass("dtp_modal-digits");
          var $d = $("<span>");
          $d.addClass("dtp_modal-digit");
          $d.attr("id", "d-hh");
          $d.text(lastSelected.format("HH"));
          $panel.append($d);
          $m = $("<span>");
          $m.addClass("dtp_modal-midle-dig");
          $m.html(":");
          $panel.append($m);
          $d = $("<span>");
          $d.addClass("dtp_modal-digit");
          $d.attr("id", "d-mm");
          $d.text(lastSelected.format("mm"));
          $panel.append($d);
          $div.append($panel);

          $panel = $("<div>");
          $panel.addClass("dtp_modal-append");
          $i = $("<i>");
          $i.attr("id", "angle-down-hour");
          $i.addClass("fa fa-angle-down ico-size-large cursorily hov");
          $panel.append($i);
          $m = $("<span>");
          $m.addClass("dtp_modal-midle");
          $panel.append($m);
          $i = $("<i>");
          $i.attr("id", "angle-down-minute");
          $i.addClass("fa fa-angle-down ico-size-large cursorily hov");
          $panel.append($i);
          $div.append($panel);
          return $div;
        }

        function createContent() {
          var $c = $("<div>");
          $c.addClass("dtp_modal-content");
          var $el = $("<div>");
          $el.addClass("dtp_modal-cell-time");
          var $a = $("<div>");
          $a.addClass("dtp_modal-time-block");
          $a.attr("id", "field-time");
          $el.append($a);
          $a.append(createTimer());
          $c.append($el);
          return $c;
        }

        //PDKIEN Update lên input
        function updateTime() {
          var hour=$("#d-hh").text();
          var minute=$("#d-mm").text();
          elem.find(".time-picker-input").val(`${hour}:${minute}`);         
        }

        function updateMainElem() {
          var $s = $("<input>");
          $s.text(lastSelected.format(settings.timeFormat));
          elem.empty();
          elem.append($s);
          $s = $("<i>");
          $s.addClass("fa fa-calendar ico-size");
          elem.append($s);
        }
      }
    });
  };
  function copyDate(d) {
    return moment(d.toDate());
  }
})(jQuery);
// fa-caret-down
