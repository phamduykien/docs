﻿using MISA.UT.BD.App.implements;
using MISA.UT.LogAnalyzer;

var fileExtensionManager = new FileExtensionManagerBD();
var logAnalyzerBD = new LogAnalyzerBD(fileExtensionManager);
//Print false
Console.WriteLine($"BreakDependency result: {logAnalyzerBD.IsValidLogFileName("test.log")}");
//Print true
Console.WriteLine($"BreakDependency result: {logAnalyzerBD.IsValidLogFileName("test.slf")}");

Console.ReadLine();
