using MISA.UT.Mock.LogAnalyzer.Test.Mock;
using NUnit.Framework;

namespace MISA.UT.Mock.LogAnalyzer.Test
{
    [TestFixture]
    public class LogAnalyzerMockTest
    {
        [Test]
        public void Analyze_TooShortFileName_CallsWebService()
        {
            //Arrange
            MockWebService mockService = new MockWebService();
            LogAnalyzerMock log = new LogAnalyzerMock(mockService);
            string tooShortFileName = "abc.ext";
            //Act
            log.Analyze(tooShortFileName);
            //Assert
            StringAssert.Contains("Filename too short:abc.ext", mockService.LastError);
        }
    }
}