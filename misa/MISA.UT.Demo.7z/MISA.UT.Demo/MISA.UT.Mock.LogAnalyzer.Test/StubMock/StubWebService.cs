﻿using MISA.UT.Mock.LogAnalyzer.interfaces;
using System;

namespace MISA.UT.Mock.LogAnalyzer.Test.StubMock
{
    public class StubWebService : IWebService
    {
        public Exception ToThrow { set; get; }
        public void LogError(string message)
        {
            if (ToThrow != null)
            {
                throw ToThrow;
            }
        }
    }
}
