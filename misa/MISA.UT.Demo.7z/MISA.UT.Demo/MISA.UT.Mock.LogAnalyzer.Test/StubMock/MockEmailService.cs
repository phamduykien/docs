﻿using MISA.UT.Mock.LogAnalyzer.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MISA.UT.Mock.LogAnalyzer.Test.StubMock
{
    public class MockEmailService : IEmailService
    {
        public string To { set; get; }
        public string Subject { set; get; }
        public string Body { set; get; }
        public void SendEmail(string to,
        string subject,
        string body)
        {
            To = to;
            Subject = subject;
            Body = body;
        }
    }
}
