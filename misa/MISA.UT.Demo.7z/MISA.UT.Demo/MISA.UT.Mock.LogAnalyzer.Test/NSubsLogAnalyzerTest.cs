﻿using MISA.UT.Mock.LogAnalyzer.interfaces;
using NSubstitute;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MISA.UT.Mock.LogAnalyzer.Test
{
    [TestFixture]
    public class NSubsLogAnalyzerTest
    {
        [Test]
        public void Analyze_WebServiceThrows_SendsEmail()
        {
            //Arrange
            IWebService stubService = Substitute.For<IWebService>();
            stubService.When(x => x.LogError(Arg.Any<string>())).Do(x => throw new Exception("fake exception"));
            IEmailService mockEmail = Substitute.For<IEmailService>();
            LogAnalyzerStubMock log = new LogAnalyzerStubMock(stubService, mockEmail);
            string tooShortFileName = "abc.ext";
            //Act
            log.Analyze(tooShortFileName);
            //Assert
            mockEmail.Received().SendEmail("nguyenvana@gmail.com", "can’t log", "fake exception");
        }
    }
}
