﻿using MISA.UT.Mock.LogAnalyzer.interfaces;

namespace MISA.UT.Mock.LogAnalyzer.Test.Mock
{
    public class MockWebService : IWebService
    {
        public string? LastError { set; get; }
        public void LogError(string message)
        {
            LastError = message;
        }
    }
}
