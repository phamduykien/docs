using MISA.UT.Mock.LogAnalyzer;
using MISA.UT.Mock.LogAnalyzer.Test.StubMock;
using NUnit.Framework;
using System;

namespace MISA.UT.Mock.LogAnalyzer.Test
{

    public class LogAnalyzerStubMockTest
    {

        [Test]
        public void Analyze_WebServiceThrows_SendsEmail()
        {
            //Arrange
            StubWebService stubService = new StubWebService();
            stubService.ToThrow = new Exception("fake exception");
            MockEmailService mockEmail = new MockEmailService();
            LogAnalyzerStubMock log = new LogAnalyzerStubMock(stubService, mockEmail);
            string tooShortFileName = "abc.ext";
            //Act
            log.Analyze(tooShortFileName);
            //Assert
            StringAssert.Contains("nguyenvana@gmail.com", mockEmail.To);
            StringAssert.Contains("fake exception", mockEmail.Body);
            StringAssert.Contains("can�t log", mockEmail.Subject);
        }
    }
}