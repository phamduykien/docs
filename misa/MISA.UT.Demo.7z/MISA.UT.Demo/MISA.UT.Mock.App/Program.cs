﻿
using MISA.UT.Mock.App.implements;
using MISA.UT.Mock.LogAnalyzer;

var webService = new MISAWebService();
var logAnMock = new LogAnalyzerMock(webService);
logAnMock.Analyze("a.txt");

var emailService = new MISAEmailService();
var logAnStubMock = new LogAnalyzerStubMock(webService,emailService);
logAnStubMock.Analyze("pass");

Console.ReadLine();
