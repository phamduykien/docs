﻿using MISA.UT.Mock.LogAnalyzer.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MISA.UT.Mock.App.implements
{
    public class MISAWebService : IWebService
    {
        public void LogError(string message)
        {
            if (message.Contains("pass"))
            {
                throw new Exception("Log message invalid!");
            }
            Console.WriteLine($"Log error with message: {message}");
        }
    }
}
