﻿using MISA.UT.Mock.LogAnalyzer.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MISA.UT.Mock.App.implements
{
    public class MISAEmailService : IEmailService
    {
        public void SendEmail(string to, string subject, string body)
        {
            Console.WriteLine($"Send email: {to} - {subject} - {body}");
        }
    }
}
