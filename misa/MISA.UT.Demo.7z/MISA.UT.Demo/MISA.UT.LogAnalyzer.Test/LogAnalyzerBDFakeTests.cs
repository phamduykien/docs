﻿using MISA.UT.LogAnalyzer.Test.Stub;
using NUnit.Framework;
using System;

namespace MISA.UT.LogAnalyzer.Test
{
    [TestFixture]
    public class LogAnalyzerBDFakeTests
    {
        private AlwaysValidFakeExtensionManager alwaysValidFakeExtensionManager = null;
        private LogAnalyzerBD analyzer = null;

        [SetUp]
        public void Setup()
        {
            alwaysValidFakeExtensionManager = new AlwaysValidFakeExtensionManager();
            analyzer = new LogAnalyzerBD(alwaysValidFakeExtensionManager);
        }
        [TearDown]
        public void TearDown()
        {
            alwaysValidFakeExtensionManager = null;
            analyzer = null;
        }

        [Test]
        public void IsValidLogFileName_GoodExtensionLowercase_ReturnsTrue()
        {
            //Act
            bool result = analyzer.IsValidLogFileName("filewithgoodextension.slf");
            //Assert
            Assert.True(result);
        }

        [Test]
        public void IsValidLogFileName_GoodExtensionUppercase_ReturnsTrue()
        {
            //Act
            bool result = analyzer.IsValidLogFileName("filewithgoodextension.SLF");
            //Assert
            Assert.True(result);
        }

        // this is a refactoring of the previous two tests
        [TestCase("filewithgoodextension.SLF")]
        [TestCase("filewithgoodextension.slf")]
        public void IsValidLogFileName_ValidExtensions_ReturnsTrue(string file)
        {
            //Act
            bool result = analyzer.IsValidLogFileName(file);
            //Assert
            Assert.True(result);
        }

    }
}