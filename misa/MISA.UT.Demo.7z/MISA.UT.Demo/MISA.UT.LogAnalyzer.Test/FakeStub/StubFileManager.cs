﻿using MISA.UT.LogAnalyzer.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MISA.UT.LogAnalyzer.Test.Stub
{
    public class StubFileManager : IFileExtensionManager
    {
        public bool WillBeValid = false;
        public bool IsValid(string fileName)
        {
            return WillBeValid;
        }
    }
}
