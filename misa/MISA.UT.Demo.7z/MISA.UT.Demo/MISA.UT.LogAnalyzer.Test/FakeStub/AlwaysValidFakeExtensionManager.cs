﻿using MISA.UT.LogAnalyzer.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MISA.UT.LogAnalyzer.Test.Stub
{
    public class AlwaysValidFakeExtensionManager : IFileExtensionManager
    {
        public bool IsValid(string fileName)
        {
            return true;
        }
    }
}
