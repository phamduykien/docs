using NUnit.Framework;
using System;

namespace MISA.UT.LogAnalyzer.Test
{
    [TestFixture]
    public class LogAnalyzerTests
    {
        private LogAnalyzer analyzer = null;

        [SetUp]
        public void Setup()
        {
            analyzer = new LogAnalyzer();
        }
        [TearDown]
        public void TearDown()
        {
            analyzer = null;
        }

        [Test, Description("Check file bad extension")]
        [Category("Long")]
        public void IsValidLogFileName_BadExtension_ReturnsFalse()
        {
            //Act
            bool result = analyzer.IsValidLogFileName("filewithbadextension.foo");
            //Assert
            Assert.False(result);
        }

        [Test]
        [Category("Short")]
        public void IsValidLogFileName_GoodExtensionLowercase_ReturnsTrue()
        {
            //Act
            bool result = analyzer.IsValidLogFileName("filewithgoodextension.slf");
            //Assert
            Assert.True(result);
        }

        [Test]
        [Category("Short")]
        public void IsValidLogFileName_GoodExtensionUppercase_ReturnsTrue()
        {
            //Act
            bool result = analyzer.IsValidLogFileName("filewithgoodextension.SLF");
            //Assert
            Assert.True(result);
        }

        // this is a refactoring of the previous two tests
        [TestCase("filewithgoodextension.SLF")]
        [TestCase("filewithgoodextension.slf")]
        [Category("Short")]
        public void IsValidLogFileName_ValidExtensions_ReturnsTrue(string file)
        {
            //Act
            bool result = analyzer.IsValidLogFileName(file);
            //Assert
            Assert.True(result);
        }

        // this is a refactoring of all the "regular" tests
        [TestCase("filewithgoodextension.SLF", true)]
        [TestCase("filewithgoodextension.slf", true)]
        [TestCase("filewithbadextension.foo", false)]
        public void IsValidLogFileName_VariousExtensions_ChecksThem(string file, bool expected)
        {
            //Act
            bool result = analyzer.IsValidLogFileName(file);
            //Assert
            Assert.AreEqual(expected, result);
        }

    }
}