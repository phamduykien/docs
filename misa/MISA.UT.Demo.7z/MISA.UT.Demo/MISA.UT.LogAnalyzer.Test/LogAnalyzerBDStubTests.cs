﻿using MISA.UT.LogAnalyzer.Test.Stub;
using NUnit.Framework;
using System;

namespace MISA.UT.LogAnalyzer.Test
{
    [TestFixture]
    public class LogAnalyzerBDStubTests
    {
        private StubFileManager stubFileManager = null;
        private LogAnalyzerBD analyzer = null;

        [SetUp]
        public void Setup()
        {
            stubFileManager = new StubFileManager();
            analyzer = new LogAnalyzerBD(stubFileManager);
        }
        [TearDown]
        public void TearDown()
        {
            stubFileManager = null;
            analyzer = null;
        }
        [Test]
        public void IsValidLogFileName_BadExtension_ReturnsFalse()
        {
            //Act
            stubFileManager.WillBeValid = false;
            bool result = analyzer.IsValidLogFileName("filewithbadextension.foo");
            //Assert
            Assert.False(result);
        }

        [Test]
        public void IsValidLogFileName_GoodExtensionLowercase_ReturnsTrue()
        {
            //Act
            stubFileManager.WillBeValid = true;
            bool result = analyzer.IsValidLogFileName("filewithgoodextension.slf");
            //Assert
            Assert.True(result);
        }

        [Test]
        public void IsValidLogFileName_GoodExtensionUppercase_ReturnsTrue()
        {
            //Act
            stubFileManager.WillBeValid = true;
            bool result = analyzer.IsValidLogFileName("filewithgoodextension.SLF");
            //Assert
            Assert.True(result);
        }

        // this is a refactoring of the previous two tests
        [TestCase("filewithgoodextension.SLF")]
        [TestCase("filewithgoodextension.slf")]
        public void IsValidLogFileName_ValidExtensions_ReturnsTrue(string file)
        {
            //Act
            stubFileManager.WillBeValid = true;
            bool result = analyzer.IsValidLogFileName(file);
            //Assert
            Assert.True(result);
        }

        // this is a refactoring of all the "regular" tests
        [TestCase("filewithgoodextension.SLF", true)]
        [TestCase("filewithgoodextension.slf", true)]
        [TestCase("filewithbadextension.foo", false)]
        public void IsValidLogFileName_VariousExtensions_ChecksThem(string file, bool expected)
        {
            //Act
            stubFileManager.WillBeValid = expected;
            bool result = analyzer.IsValidLogFileName(file);
            //Assert
            Assert.AreEqual(expected, result);
        }

    }
}