﻿using MISA.UT.Mock.LogAnalyzer.interfaces;
using System.Configuration;

namespace MISA.UT.Mock.LogAnalyzer
{
    public class LogAnalyzerMock
    {
        private IWebService _websSrvice;
        public bool WasLastFileNameValid { get; set; }
        public LogAnalyzerMock(IWebService websSrvice)
        {
            this._websSrvice = websSrvice;
        }
        public void Analyze(string fileName)
        {
            WasLastFileNameValid = false;
            if (fileName.Length < 8)
            {
                _websSrvice.LogError("Filename too short:"
                + fileName);
                return;
            }
            WasLastFileNameValid = true;
        }
    }
}
