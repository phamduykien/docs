﻿using MISA.UT.Mock.LogAnalyzer.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MISA.UT.Mock.LogAnalyzer
{
    public class LogAnalyzerStubMock
    {
        private IWebService _websSrvice;
        private IEmailService _emailService;
        public LogAnalyzerStubMock(IWebService websSrvice, IEmailService emailService)
        {
            this._websSrvice = websSrvice;
            this._emailService = emailService;
        }
        public void Analyze(string fileName)
        {
            if (fileName.Length < 8)
            {
                try
                {
                    //Chay den day la phai throw => stub
                    _websSrvice.LogError("Filename too short:" + fileName);
                }
                catch (Exception e)
                {
                    _emailService.SendEmail("nguyenvana@gmail.com", "can’t log", e.Message);
                }
            }
        }
    }
}
