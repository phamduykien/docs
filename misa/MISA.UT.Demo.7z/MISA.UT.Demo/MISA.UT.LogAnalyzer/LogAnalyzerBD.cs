﻿using MISA.UT.LogAnalyzer.interfaces;
using System.Configuration;

namespace MISA.UT.LogAnalyzer
{
    public class LogAnalyzerBD
    {
        private readonly IFileExtensionManager _extensionManager;
        public LogAnalyzerBD(IFileExtensionManager extensionManager)
        {
            this._extensionManager = extensionManager;
        }
        public bool WasLastFileNameValid { get; set; }
        public bool IsValidLogFileName(string fileName)
        {
            WasLastFileNameValid = false;

            if (string.IsNullOrEmpty(fileName))
            {
                throw new ArgumentException("filename has to be provided");
            }
            if (!_extensionManager.IsValid(fileName))
            {
                return false;
            }
            WasLastFileNameValid = true;
            return true;
        }
    }
}



