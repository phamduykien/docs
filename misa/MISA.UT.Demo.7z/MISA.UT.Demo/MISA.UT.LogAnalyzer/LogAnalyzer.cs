﻿using System;
using System.Configuration;
namespace MISA.UT.LogAnalyzer
{
    public class LogAnalyzer
    {
        public bool WasLastFileNameValid { get; set; }

        public bool IsValidLogFileName(string fileName)
        {
            WasLastFileNameValid = false;

            if (string.IsNullOrEmpty(fileName))
            {
                throw new ArgumentException("filename has to be provided");
            }
            var extenstion = string.IsNullOrEmpty(ConfigurationManager.AppSettings["extensionsupport"]) ? ".SLF"
                : ConfigurationManager.AppSettings["ExtensionSupport"];
            if (!fileName.EndsWith(extenstion, StringComparison.CurrentCultureIgnoreCase))
            {
                return false;
            }

            WasLastFileNameValid = true;
            return true;
        }

    }
}