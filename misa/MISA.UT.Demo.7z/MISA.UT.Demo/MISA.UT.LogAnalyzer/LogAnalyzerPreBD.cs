﻿using System.Configuration;

namespace MISA.UT.LogAnalyzer
{
    public class LogAnalyzerPreBD
    {
        public bool WasLastFileNameValid { get; set; }
        public bool IsValidLogFileName(string fileName)
        {
            var fileExtensionManagerPreBD = new FileExtensionManagerPreBD();
            WasLastFileNameValid = false;

            if (string.IsNullOrEmpty(fileName))
            {
                throw new ArgumentException("filename has to be provided");
            }
            if (!fileExtensionManagerPreBD.IsValid(fileName))
            {
                return false;
            }

            WasLastFileNameValid = true;
            return true;
        }

    }
}

public class FileExtensionManagerPreBD
{
    public bool IsValid(string fileName)
    {
        var extenstion = string.IsNullOrEmpty(ConfigurationManager.AppSettings["extensionsupport"]) ? ".SLF"
            : ConfigurationManager.AppSettings["ExtensionSupport"];
        if (!fileName.EndsWith(extenstion, StringComparison.CurrentCultureIgnoreCase))
        {
            return false;
        }
        return true;
    }
}