﻿
var MISA = MISA || {};
MISA.mask = {
    hide: function () {
        console.log("hide mask");
    },
    show: function () {
        console.log("show mask");
    }

}

MISA.Constant = MISA.Constant || {};
MISA.Constant.MessageBox = {
    Warning: "Warning",


}
MISA.Resource = MISA.Resource || {};
MISA.Resource.EinvoiceResource = {
    ErrorBrower: "ErrorBrower"
}

MISA.CommonFn = {
    showError: function (title, message) {
        console.log("show error: " + message);
    },
    showMessageBox: function (type, title, message, callback, options) {
        console.log("show message:" + message);
    }
}


var kyso = {
    message_NoSetup_misakyso: 'Để thực hiện ký điện tử, bạn cần cài đặt công cụ MISA KYSO. Tải bộ cài <a id="download-ky-so" style="color:#2a6496" target="_blank" onclick="misa_kyso.clickDownloadKyso()">tại đây</a>.',
    isCalling_Misa_Kyso: false,
    ports: [11984, 11978, 11979, 11985, 11984, 12680],
    webSocket: null,
    portIndex: 0,
    connectStatus: false,
    securityError: true,
    Action: {
        GetRawVersion: 'GetRawVersion',
        GetVersionNumber: 'GetVersionNumber',
        SignXML: 'SignXML',
        GetAllCertificates: 'GetAllCertificates',
        GetAllCertificatesNotValidateTaxCode: 'GetAllCertificatesNotValidateTaxCode',
        SignPDF: 'SignPDF',
        SignOffice: 'SignOffice',
        CheckSignXML: 'CheckSignXML',
        SignXmlInvoiceUsingInfor: 'SignXmlInvoiceUsingInfor',
        GetSysInfor: 'GetSysInfor'
    },
    ErrorCode: {
        BrowserNotSupport: 'BrowserNotSupport',
        PluginNotExist: 'PluginNotExist',
        RuntimeError: 'RuntimeError'
    },
    connect: function (port, data, count) {
        var me = this
            , jsonData = JSON.stringify(data);
        if (me.webSocket == null || me.connectStatus == false) {
            try {
                me.webSocket = new WebSocket("ws://localhost:" + port + "/plugin");
            } catch (ex) {
                MISA.CommonFn.showMessageBox("MISA kyso", "MISA kyso", "Không thể khởi tạo socket");
            }
        } else {
            me.webSocket.send(jsonData);
        }
        me.webSocket.onopen = function (e) {
            me.connectStatus = true;
            me.securityError = false;
            me.webSocket.send(jsonData);
        }
            ;
        me.webSocket.onclose = function (e) {
            me.connectStatus = false;
            me.securityError = false;
            me.isCalling_Misa_Kyso = false;
        }
            ;
        me.webSocket.onmessage = function (e) {
            var res, serviceResult = me.ServiceResult;
            me.isCalling_Misa_Kyso = false;
            if (e && e.data) {
                res = JSON.parse(e.data);
                if (res?.status) {
                    alert("Ky thanh cong");
                } else {
                    alert("Ky that bai");
                }
            }
        }
            ;
        me.webSocket.onerror = function (e) {
            console.log(e);
            me.connectStatus = false;
            me.securityError = false;
            me.webSocket = null;
            if (count == 0) {
                count++;
                window.location.href = 'misa://misa_kyso_path';
                me.connect(port, data, count);
            } else {
                me.portIndex += 1;
                if (me.portIndex < me.ports.length) {
                    me.connect(me.ports[me.portIndex], data, count);
                } else {
                    MISA.CommonFn.showMessageBox("MISA kyso", "MISA kyso", "Không thể kết nối với plugin ký số");
                }
            }
        }
            ;
    },
    reconnect: function (data) {
        var me = this;
        me.connect(me.ports[me.portIndex], data, 0);
    },
    getRawVersion: function (callbackFn, jsObject) {
        var me = this
            , data = {
                action: me.Action.GetRawVersion
            };
        this.sendDataToPlugin(data, callbackFn, jsObject);
    },
    getRawVersionV2: function (jsObject, callbackFn) {
        var me = this
            , data = {
                action: me.Action.GetRawVersion,
                jsObject: jsObject,
                jsCallBackFn: callbackFn
            };
        this.sendDataToPlugin(data, callbackFn, jsObject);
    },
    getVersionNumber: function (callbackFn, jsObject) {
        var me = this
            , data = {
                action: me.Action.GetVersionNumber
            };
        me.sendDataToPlugin(data, callbackFn, jsObject);
    },
    checkSignXML: function (data, callbackFn, jsObject) {
        var me = this;
        me.sendDataToPlugin(data, callbackFn, jsObject);
    },
    GetCertificateFromSignedXML: function (data, callbackFn, jsObject) {
        var me = this;
        me.sendDataToPlugin(data, callbackFn, jsObject);
    },
    mask: "",
    signXML: function (data, callbackFn, jsObject, parent_mask) {
        var me = this;
        if (parent_mask) {
            this.mask = parent_mask;
        }
        me.sendDataToPlugin(data, callbackFn, jsObject);
    },
    sendDataToPlugin: function (data, callbackFn, jsObject) {
        var me = this
            , data = data || {};
        if (callbackFn && (!data.jsCallBackFn || data.jsCallBackFn == '')) {
            data.jsCallBackFn = me.getFnName(callbackFn);
        }
        if (jsObject && (!data.jsObject || data.jsObject == '')) {
            data.jsObject = me.getInstanceName(jsObject);
        }
        if (me.portIndex < me.ports.length) {
            me.connect(me.ports[me.portIndex], data, 0);
        } else {
            MISA.CommonFn.showError('MISA kyso', 'Không thể gửi data sang kyso');
        }
    },
    checkBrowserSupportWS: function () {
        var t = get_browser()
            , isSupport = false;
        switch (t.name.toLowerCase()) {
            case "chrome":
                if (t.version > 44) {
                    isSupport = true;
                }
                break;
            case "firefox":
                if (t.version > 41) {
                    isSupport = true;
                }
                break;
            case "opera":
                if (t.version > 26) {
                    isSupport = true;
                }
                break;
            case "edge":
                if (t.version > 15) {
                    isSupport = true;
                }
                break;
            case "safari":
                if (t.version > 10) {
                    isSupport = true;
                }
                break;
        }
        return isSupport;
    },
    getFnName: function (fn) {
        if (typeof fn == 'string') {
            return fn;
        }
        var f = typeof fn == 'function';
        var s = f && ((fn.name && ['', fn.name]) || fn.toString().match(/function ([^\(]+)/));
        return (!f && 'not a function') || (s && s[1] || 'anonymous');
    },
    getInstanceName: function (obj) {
        if (typeof obj == 'string') {
            return obj;
        }
        for (var name in window) {
            if (window[name] == obj) {
                return name;
            }
        }
    },
    hanlderErrorConnectKySo: function () { },
    getAllCertificates: function (data, callbackFn, jsObject) {
        var me = this;
        me.sendDataToPlugin(data, callbackFn, jsObject);
    }


};

$(document).ready(function () {
    /**
     * Ký thì lấy từ input file ra encode base64 để gọi plugin ký
     */
    $("#btnSignFile").click(function () {
        //read file from input as base64
        const file = document.getElementById('file').files[0];
        const reader = new FileReader();
        reader.onloadend = function () {
            const base64 = reader.result.substring("data:text/xml;base64,".length);
            var data = {
                "sessionId": "17139780006815f14c776-48c0-4740-b387-15e6d4798b97",
                "productName": "MISA meInvoice",
                "action": "SignXML",
                "taxcode": "0101243150-999",
                "sellerInfo": {
                    "sellerTaxCode": "0101243150-999",
                    "sellerAddressLine": "Thửa đất số 962, Tờ bản đồ số 5, Tổ 9, Ấp Suối Đá, Xã Dương Tơ, Thành phố Phú Quốc, Tỉnh Kiên Giang, Việt Nam",
                    "sellerPhoneNumber": ""
                },
                "files": [{
                    "name": "InvoiceXMLTemplate.xml",
                    "data": base64,
                    "invoiceElectronicID": "9679ecdc-0daf-0e6e-f53e-2c6f264ebe86",
                    "transactionID": "NDCEH1QM0VV_"
                }
                ],
                "jsObject": "oPublicInvoice",
                "invoiceDatas": 1,
                "jsCallBackFn": "callbackElectronicSignXML",
                "isSendEmail": true,
                "isSelectFromCollection": false,
                "isSignTT68": false,
                "isSignTT32": false,
                "expiredPrompt": false
            }
            kyso.signXML(data, function (a, b, c, d) {
                cconsole.log("Gọi xong kyso");

            });
        }
        reader.readAsDataURL(file);


    });

    $("#btnSignBase64").click(function () {
        //read file from input as base64
        const base64 = $("#txtBase64").val();

        var data = {
            "sessionId": "17139780006815f14c776-48c0-4740-b387-15e6d4798b97",
            "productName": "MISA meInvoice",
            "action": "SignXML",
            "taxcode": "0101243150-999",
            "sellerInfo": {
                "sellerTaxCode": "0101243150-999",
                "sellerAddressLine": "Thửa đất số 962, Tờ bản đồ số 5, Tổ 9, Ấp Suối Đá, Xã Dương Tơ, Thành phố Phú Quốc, Tỉnh Kiên Giang, Việt Nam",
                "sellerPhoneNumber": ""
            },
            "files": [{
                "name": "InvoiceXMLTemplate.xml",                
                "data": base64,
                "invoiceElectronicID": "9679ecdc-0daf-0e6e-f53e-2c6f264ebe86",
                "transactionID": "NDCEH1QM0VV_"
            }
            ],
            "jsObject": "oPublicInvoice",
            "invoiceDatas": 1,
            "jsCallBackFn": "callbackElectronicSignXML",
            "isSendEmail": true,
            "isSelectFromCollection": false,
            "isSignTT68": false,
            "isSignTT32": false,
            "expiredPrompt": false
        }
        kyso.signXML(data, function (a, b, c, d) {
            cconsole.log("Gọi xong kyso");

        });

    });

});
/**
 * 
 * PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz48SERvbj48RExIRG9uIElkPSJORENFSDFRTTBWVl8iPjxUVENodW5nPjxQQmFuPjIuMC4xPC9QQmFuPjxUSERvbj5Iw7NhIMSRxqFuIEdUR1Qga2jhu59pIHThuqFvIHThu6sgbcOheSB0w61uaCB0aeG7gW48L1RIRG9uPjxLSE1TSERvbj4xPC9LSE1TSERvbj48S0hIRG9uPkMyNE1FUzwvS0hIRG9uPjxTSERvbj4wMDAwMDAwNzwvU0hEb24+PE5MYXA+MjAyNC0wNC0yNTwvTkxhcD48RFZUVGU+Vk5EPC9EVlRUZT48VEdpYT4xLjAwPC9UR2lhPjxNU1RUQ0dQPjAxMDEyNDMxNTA8L01TVFRDR1A+PFRUS2hhYz48VFRpbj48VFRydW9uZz5FbnZpcm9ubW1lbnRGZWVSYXRlPC9UVHJ1b25nPjxLRExpZXU+bnVtZXJpYzwvS0RMaWV1PjxETGlldT4wLjA8L0RMaWV1PjwvVFRpbj48L1RUS2hhYz48L1RUQ2h1bmc+PE5ESERvbj48TkJhbj48VGVuPkPDlE5HIFRZIFROSEggUEjGr+G7mkMgVFLDgk0gUEjDmiBRVeG7kEM8L1Rlbj48TVNUPjAxMDEyNDMxNTAtOTk2PC9NU1Q+PERDaGk+VGjhu61hIMSR4bqldCBz4buRIDk2MiwgVOG7nSBi4bqjbiDEkeG7kyBz4buRIDUsIFThu5UgOSwg4bqkcCBTdeG7kWkgxJDDoSwgWMOjIETGsMahbmcgVMahLCBUaMOgbmggcGjhu5EgUGjDuiBRdeG7kWMsIFThu4luaCBLacOqbiBHaWFuZywgVmnhu4d0IE5hbTwvRENoaT48RENURFR1Pmgyc3ZpZXRuYW1AZ21haWwuY29tPC9EQ1REVHU+PFNUS05IYW5nPjEyMzwvU1RLTkhhbmc+PFROSGFuZz5BQ0I8L1ROSGFuZz48V2Vic2l0ZT53d3cua2Vud2F2bi5jb208L1dlYnNpdGU+PFRUS2hhYz48VFRpbj48VFRydW9uZz5TZWxsZXJBZGRyZXNzPC9UVHJ1b25nPjxLRExpZXU+c3RyaW5nPC9LRExpZXU+PERMaWV1PlRo4butYSDEkeG6pXQgc+G7kSA5NjIsIFThu50gYuG6o24gxJHhu5Mgc+G7kSA1LCBU4buVIDksIOG6pHAgU3Xhu5FpIMSQw6EsIFjDoyBExrDGoW5nIFTGoSwgVGjDoG5oIHBo4buRIFBow7ogUXXhu5FjLCBU4buJbmggS2nDqm4gR2lhbmcsIFZp4buHdCBOYW08L0RMaWV1PjwvVFRpbj48VFRpbj48VFRydW9uZz5TZWxsZXJCYW5rQWNjb3VudDwvVFRydW9uZz48S0RMaWV1PnN0cmluZzwvS0RMaWV1PjxETGlldT4xMjM8L0RMaWV1PjwvVFRpbj48VFRpbj48VFRydW9uZz5TZWxsZXJCYW5rTmFtZTwvVFRydW9uZz48S0RMaWV1PnN0cmluZzwvS0RMaWV1PjxETGlldT5BQ0I8L0RMaWV1PjwvVFRpbj48VFRpbj48VFRydW9uZz5TZWxsZXJFbWFpbDwvVFRydW9uZz48S0RMaWV1PnN0cmluZzwvS0RMaWV1PjxETGlldT5oMnN2aWV0bmFtQGdtYWlsLmNvbTwvRExpZXU+PC9UVGluPjxUVGluPjxUVHJ1b25nPlNlbGxlcldlYnNpdGU8L1RUcnVvbmc+PEtETGlldT5zdHJpbmc8L0tETGlldT48RExpZXU+d3d3Lmtlbndhdm4uY29tPC9ETGlldT48L1RUaW4+PC9UVEtoYWM+PC9OQmFuPjxOTXVhPjwvTk11YT48RFNISERWdT48SEhEVnU+PFRDaGF0PjQ8L1RDaGF0PjxTVFQ+MTwvU1RUPjxUSEhEVnU+cGjDsm5nIG5naOG7iTwvVEhIRFZ1PjxTTHVvbmc+MC4wMDAwMDA8L1NMdW9uZz48REdpYT4wLjAwMDAwMDwvREdpYT48VExDS2hhdT4wLjAwMDA8L1RMQ0toYXU+PFNUQ0toYXU+MC4wMDAwMDA8L1NUQ0toYXU+PFRoVGllbj4wLjAwMDAwMDwvVGhUaWVuPjxUVEtoYWM+PFRUaW4+PFRUcnVvbmc+QW1vdW50PC9UVHJ1b25nPjxLRExpZXU+bnVtZXJpYzwvS0RMaWV1PjxETGlldT4wLjA8L0RMaWV1PjwvVFRpbj48VFRpbj48VFRydW9uZz5BbW91bnRBZnRlckV4Y2lzZVRheDwvVFRydW9uZz48S0RMaWV1Pm51bWVyaWM8L0tETGlldT48RExpZXU+MC4wPC9ETGlldT48L1RUaW4+PFRUaW4+PFRUcnVvbmc+QW1vdW50QWZ0ZXJFeGNpc2VUYXhPQzwvVFRydW9uZz48S0RMaWV1Pm51bWVyaWM8L0tETGlldT48RExpZXU+MC4wPC9ETGlldT48L1RUaW4+PFRUaW4+PFRUcnVvbmc+QW1vdW50QWZ0ZXJUYXg8L1RUcnVvbmc+PEtETGlldT5udW1lcmljPC9LRExpZXU+PERMaWV1PjAuMDwvRExpZXU+PC9UVGluPjxUVGluPjxUVHJ1b25nPkFtb3VudE9DPC9UVHJ1b25nPjxLRExpZXU+bnVtZXJpYzwvS0RMaWV1PjxETGlldT4wLjA8L0RMaWV1PjwvVFRpbj48VFRpbj48VFRydW9uZz5BbW91bnRXaXRob3V0VkFUT0M8L1RUcnVvbmc+PEtETGlldT5udW1lcmljPC9LRExpZXU+PERMaWV1PjAuMDwvRExpZXU+PC9UVGluPjxUVGluPjxUVHJ1b25nPkN1c3RvbUZpZWxkMURldGFpbDwvVFRydW9uZz48S0RMaWV1PnN0cmluZzwvS0RMaWV1PjxETGlldT4wLDAwMDAwPC9ETGlldT48L1RUaW4+PFRUaW4+PFRUcnVvbmc+RGlzY291bnRBbW91bnQ8L1RUcnVvbmc+PEtETGlldT5udW1lcmljPC9LRExpZXU+PERMaWV1PjAuMDwvRExpZXU+PC9UVGluPjxUVGluPjxUVHJ1b25nPlRheFJlZHVjdGlvbkFtb3VudDwvVFRydW9uZz48S0RMaWV1Pm51bWVyaWM8L0tETGlldT48RExpZXU+MC4wPC9ETGlldT48L1RUaW4+PFRUaW4+PFRUcnVvbmc+VGF4UmVkdWN0aW9uQW1vdW50T0M8L1RUcnVvbmc+PEtETGlldT5udW1lcmljPC9LRExpZXU+PERMaWV1PjAuMDwvRExpZXU+PC9UVGluPjxUVGluPjxUVHJ1b25nPlVuaXRQcmljZTwvVFRydW9uZz48S0RMaWV1Pm51bWVyaWM8L0tETGlldT48RExpZXU+MC4wPC9ETGlldT48L1RUaW4+PFRUaW4+PFRUcnVvbmc+VW5pdFByaWNlQWZ0ZXJFeGNpc2VWQVQ8L1RUcnVvbmc+PEtETGlldT5udW1lcmljPC9LRExpZXU+PERMaWV1PjAuMDwvRExpZXU+PC9UVGluPjxUVGluPjxUVHJ1b25nPlVuaXRQcmljZUFmdGVyVGF4PC9UVHJ1b25nPjxLRExpZXU+bnVtZXJpYzwvS0RMaWV1PjxETGlldT4wLjA8L0RMaWV1PjwvVFRpbj48VFRpbj48VFRydW9uZz5WQVRBbW91bnQ8L1RUcnVvbmc+PEtETGlldT5udW1lcmljPC9LRExpZXU+PERMaWV1PjAuMDwvRExpZXU+PC9UVGluPjxUVGluPjxUVHJ1b25nPlZBVEFtb3VudE9DPC9UVHJ1b25nPjxLRExpZXU+bnVtZXJpYzwvS0RMaWV1PjxETGlldT4wLjA8L0RMaWV1PjwvVFRpbj48VFRpbj48VFRydW9uZz5XYWdlQW1vdW50PC9UVHJ1b25nPjxLRExpZXU+bnVtZXJpYzwvS0RMaWV1PjxETGlldT4wLjA8L0RMaWV1PjwvVFRpbj48VFRpbj48VFRydW9uZz5XYWdlQW1vdW50T0M8L1RUcnVvbmc+PEtETGlldT5udW1lcmljPC9LRExpZXU+PERMaWV1PjAuMDwvRExpZXU+PC9UVGluPjxUVGluPjxUVHJ1b25nPldhZ2VEaXNjb3VudEFtb3VudE9DPC9UVHJ1b25nPjxLRExpZXU+bnVtZXJpYzwvS0RMaWV1PjxETGlldT4wLjA8L0RMaWV1PjwvVFRpbj48VFRpbj48VFRydW9uZz5XYWdlUHJpY2VBbW91bnQ8L1RUcnVvbmc+PEtETGlldT5udW1lcmljPC9LRExpZXU+PERMaWV1PjAuMDwvRExpZXU+PC9UVGluPjxUVGluPjxUVHJ1b25nPldhZ2VQcmljZURpc2NvdW50QW1vdW50PC9UVHJ1b25nPjxLRExpZXU+bnVtZXJpYzwvS0RMaWV1PjxETGlldT4wLjA8L0RMaWV1PjwvVFRpbj48VFRpbj48VFRydW9uZz5Vbml0UHJpY2VBZnRlckV4Y2lzZVZBVDwvVFRydW9uZz48S0RMaWV1Pm51bWVyaWM8L0tETGlldT48RExpZXU+MC4wPC9ETGlldT48L1RUaW4+PFRUaW4+PFRUcnVvbmc+QW1vdW50QWZ0ZXJFeGNpc2VUYXhPQzwvVFRydW9uZz48S0RMaWV1Pm51bWVyaWM8L0tETGlldT48RExpZXU+MC4wPC9ETGlldT48L1RUaW4+PFRUaW4+PFRUcnVvbmc+QW1vdW50QWZ0ZXJFeGNpc2VUYXg8L1RUcnVvbmc+PEtETGlldT5udW1lcmljPC9LRExpZXU+PERMaWV1PjAuMDwvRExpZXU+PC9UVGluPjwvVFRLaGFjPjwvSEhEVnU+PEhIRFZ1PjxUQ2hhdD4xPC9UQ2hhdD48U1RUPjI8L1NUVD48VEhIRFZ1PnBow7JuZyBuZ2jhu4k8L1RISERWdT48U0x1b25nPjEuMDAwMDAwPC9TTHVvbmc+PERHaWE+MzAwMDAwLjAwMDAwMDwvREdpYT48VExDS2hhdT4wLjAwMDA8L1RMQ0toYXU+PFNUQ0toYXU+MC4wMDAwMDA8L1NUQ0toYXU+PFRoVGllbj4zMDAwMDAuMDAwMDAwPC9UaFRpZW4+PFRTdWF0PjEwJTwvVFN1YXQ+PFRUS2hhYz48VFRpbj48VFRydW9uZz5BbW91bnQ8L1RUcnVvbmc+PEtETGlldT5udW1lcmljPC9LRExpZXU+PERMaWV1PjMwMDAwMC4wPC9ETGlldT48L1RUaW4+PFRUaW4+PFRUcnVvbmc+QW1vdW50QWZ0ZXJFeGNpc2VUYXg8L1RUcnVvbmc+PEtETGlldT5udW1lcmljPC9LRExpZXU+PERMaWV1PjAuMDwvRExpZXU+PC9UVGluPjxUVGluPjxUVHJ1b25nPkFtb3VudEFmdGVyRXhjaXNlVGF4T0M8L1RUcnVvbmc+PEtETGlldT5udW1lcmljPC9LRExpZXU+PERMaWV1PjAuMDwvRExpZXU+PC9UVGluPjxUVGluPjxUVHJ1b25nPkFtb3VudEFmdGVyVGF4PC9UVHJ1b25nPjxLRExpZXU+bnVtZXJpYzwvS0RMaWV1PjxETGlldT4wLjA8L0RMaWV1PjwvVFRpbj48VFRpbj48VFRydW9uZz5BbW91bnRPQzwvVFRydW9uZz48S0RMaWV1Pm51bWVyaWM8L0tETGlldT48RExpZXU+MzAwMDAwLjA8L0RMaWV1PjwvVFRpbj48VFRpbj48VFRydW9uZz5BbW91bnRXaXRob3V0VkFUT0M8L1RUcnVvbmc+PEtETGlldT5udW1lcmljPC9LRExpZXU+PERMaWV1PjMwMDAwMC4wPC9ETGlldT48L1RUaW4+PFRUaW4+PFRUcnVvbmc+Q3VzdG9tRmllbGQxRGV0YWlsPC9UVHJ1b25nPjxLRExpZXU+c3RyaW5nPC9LRExpZXU+PERMaWV1PjAsMDAwMDA8L0RMaWV1PjwvVFRpbj48VFRpbj48VFRydW9uZz5EaXNjb3VudEFtb3VudDwvVFRydW9uZz48S0RMaWV1Pm51bWVyaWM8L0tETGlldT48RExpZXU+MC4wPC9ETGlldT48L1RUaW4+PFRUaW4+PFRUcnVvbmc+U29ydE9yZGVyPC9UVHJ1b25nPjxLRExpZXU+bnVtZXJpYzwvS0RMaWV1PjxETGlldT4xPC9ETGlldT48L1RUaW4+PFRUaW4+PFRUcnVvbmc+VGF4UmVkdWN0aW9uNDNBbW91bnQ8L1RUcnVvbmc+PEtETGlldT5udW1lcmljPC9LRExpZXU+PERMaWV1PjAuMDwvRExpZXU+PC9UVGluPjxUVGluPjxUVHJ1b25nPlRheFJlZHVjdGlvbjQzQW1vdW50T0M8L1RUcnVvbmc+PEtETGlldT5udW1lcmljPC9LRExpZXU+PERMaWV1PjAuMDwvRExpZXU+PC9UVGluPjxUVGluPjxUVHJ1b25nPlRheFJlZHVjdGlvbkFtb3VudDwvVFRydW9uZz48S0RMaWV1Pm51bWVyaWM8L0tETGlldT48RExpZXU+MC4wPC9ETGlldT48L1RUaW4+PFRUaW4+PFRUcnVvbmc+VGF4UmVkdWN0aW9uQW1vdW50T0M8L1RUcnVvbmc+PEtETGlldT5udW1lcmljPC9LRExpZXU+PERMaWV1PjAuMDwvRExpZXU+PC9UVGluPjxUVGluPjxUVHJ1b25nPlVuaXRQcmljZTwvVFRydW9uZz48S0RMaWV1Pm51bWVyaWM8L0tETGlldT48RExpZXU+MzAwMDAwLjA8L0RMaWV1PjwvVFRpbj48VFRpbj48VFRydW9uZz5Vbml0UHJpY2VBZnRlckV4Y2lzZVZBVDwvVFRydW9uZz48S0RMaWV1Pm51bWVyaWM8L0tETGlldT48RExpZXU+MC4wPC9ETGlldT48L1RUaW4+PFRUaW4+PFRUcnVvbmc+VW5pdFByaWNlQWZ0ZXJUYXg8L1RUcnVvbmc+PEtETGlldT5udW1lcmljPC9LRExpZXU+PERMaWV1PjAuMDwvRExpZXU+PC9UVGluPjxUVGluPjxUVHJ1b25nPlZBVEFtb3VudDwvVFRydW9uZz48S0RMaWV1Pm51bWVyaWM8L0tETGlldT48RExpZXU+MzAwMDAuMDwvRExpZXU+PC9UVGluPjxUVGluPjxUVHJ1b25nPlZBVEFtb3VudE9DPC9UVHJ1b25nPjxLRExpZXU+bnVtZXJpYzwvS0RMaWV1PjxETGlldT4zMDAwMC4wPC9ETGlldT48L1RUaW4+PFRUaW4+PFRUcnVvbmc+V2FnZUFtb3VudDwvVFRydW9uZz48S0RMaWV1Pm51bWVyaWM8L0tETGlldT48RExpZXU+MC4wPC9ETGlldT48L1RUaW4+PFRUaW4+PFRUcnVvbmc+V2FnZUFtb3VudE9DPC9UVHJ1b25nPjxLRExpZXU+bnVtZXJpYzwvS0RMaWV1PjxETGlldT4wLjA8L0RMaWV1PjwvVFRpbj48VFRpbj48VFRydW9uZz5XYWdlRGlzY291bnRBbW91bnRPQzwvVFRydW9uZz48S0RMaWV1Pm51bWVyaWM8L0tETGlldT48RExpZXU+MC4wPC9ETGlldT48L1RUaW4+PFRUaW4+PFRUcnVvbmc+V2FnZVByaWNlQW1vdW50PC9UVHJ1b25nPjxLRExpZXU+bnVtZXJpYzwvS0RMaWV1PjxETGlldT4wLjA8L0RMaWV1PjwvVFRpbj48VFRpbj48VFRydW9uZz5XYWdlUHJpY2VEaXNjb3VudEFtb3VudDwvVFRydW9uZz48S0RMaWV1Pm51bWVyaWM8L0tETGlldT48RExpZXU+MC4wPC9ETGlldT48L1RUaW4+PFRUaW4+PFRUcnVvbmc+VW5pdFByaWNlQWZ0ZXJFeGNpc2VWQVQ8L1RUcnVvbmc+PEtETGlldT5udW1lcmljPC9LRExpZXU+PERMaWV1PjAuMDwvRExpZXU+PC9UVGluPjxUVGluPjxUVHJ1b25nPkFtb3VudEFmdGVyRXhjaXNlVGF4T0M8L1RUcnVvbmc+PEtETGlldT5udW1lcmljPC9LRExpZXU+PERMaWV1PjAuMDwvRExpZXU+PC9UVGluPjxUVGluPjxUVHJ1b25nPkFtb3VudEFmdGVyRXhjaXNlVGF4PC9UVHJ1b25nPjxLRExpZXU+bnVtZXJpYzwvS0RMaWV1PjxETGlldT4wLjA8L0RMaWV1PjwvVFRpbj48L1RUS2hhYz48L0hIRFZ1PjwvRFNISERWdT48VFRvYW4+PFRIVFRMVFN1YXQ+PExUU3VhdD48VFN1YXQ+MTAlPC9UU3VhdD48VGhUaWVuPjMwMDAwMC4wMDAwMDA8L1RoVGllbj48VFRodWU+MzAwMDAuMDAwMDAwPC9UVGh1ZT48L0xUU3VhdD48L1RIVFRMVFN1YXQ+PFRnVENUaHVlPjMwMDAwMC4wMDAwMDA8L1RnVENUaHVlPjxUZ1RUaHVlPjMwMDAwLjAwMDAwMDwvVGdUVGh1ZT48VFRDS1RNYWk+MC4wMDAwMDA8L1RUQ0tUTWFpPjxUZ1RUVEJTbz4zMzAwMDAuMDAwMDAwPC9UZ1RUVEJTbz48VGdUVFRCQ2h1PkJhIHRyxINtIGJhIG3GsMahaSBuZ2jDrG4gxJHhu5NuZyBjaOG6tW4uPC9UZ1RUVEJDaHU+PFRUS2hhYz48VFRpbj48VFRydW9uZz5Ub3RhbEFtb3VudDwvVFRydW9uZz48S0RMaWV1Pm51bWVyaWM8L0tETGlldT48RExpZXU+MzMwMDAwLjA8L0RMaWV1PjwvVFRpbj48VFRpbj48VFRydW9uZz5Ub3RhbEFtb3VudEluV29yZHNCeUVORzwvVFRydW9uZz48S0RMaWV1PnN0cmluZzwvS0RMaWV1PjxETGlldT5UaHJlZSBodW5kcmVkIHRoaXJ0eSB0aG91c2FuZCBkb25ncy48L0RMaWV1PjwvVFRpbj48VFRpbj48VFRydW9uZz5Ub3RhbEFtb3VudFdpdGhvdXRWQVQ8L1RUcnVvbmc+PEtETGlldT5udW1lcmljPC9LRExpZXU+PERMaWV1PjMwMDAwMC4wPC9ETGlldT48L1RUaW4+PFRUaW4+PFRUcnVvbmc+VG90YWxBbW91bnRXaXRob3V0VkFUT0M8L1RUcnVvbmc+PEtETGlldT5udW1lcmljPC9LRExpZXU+PERMaWV1PjMwMDAwMC4wPC9ETGlldT48L1RUaW4+PFRUaW4+PFRUcnVvbmc+VG90YWxEaXNjb3VudEFtb3VudDwvVFRydW9uZz48S0RMaWV1Pm51bWVyaWM8L0tETGlldT48RExpZXU+MC4wPC9ETGlldT48L1RUaW4+PFRUaW4+PFRUcnVvbmc+VG90YWxEaXNjb3VudEFtb3VudE9DPC9UVHJ1b25nPjxLRExpZXU+bnVtZXJpYzwvS0RMaWV1PjxETGlldT4wLjA8L0RMaWV1PjwvVFRpbj48VFRpbj48VFRydW9uZz5Ub3RhbFNhbGVBbW91bnQ8L1RUcnVvbmc+PEtETGlldT5udW1lcmljPC9LRExpZXU+PERMaWV1PjMwMDAwMC4wPC9ETGlldT48L1RUaW4+PFRUaW4+PFRUcnVvbmc+VG90YWxTYWxlQW1vdW50T0M8L1RUcnVvbmc+PEtETGlldT5udW1lcmljPC9LRExpZXU+PERMaWV1PjMwMDAwMC4wPC9ETGlldT48L1RUaW4+PFRUaW4+PFRUcnVvbmc+VG90YWxWQVRBbW91bnQ8L1RUcnVvbmc+PEtETGlldT5udW1lcmljPC9LRExpZXU+PERMaWV1PjMwMDAwLjA8L0RMaWV1PjwvVFRpbj48L1RUS2hhYz48L1RUb2FuPjwvTkRIRG9uPjxUVEtoYWM+PFRUaW4+PFRUcnVvbmc+SW52b2ljZVRlbXBsYXRlSUQ8L1RUcnVvbmc+PEtETGlldT5zdHJpbmc8L0tETGlldT48RExpZXU+MzU0MTA5ODctNjIxMS00YjAxLWFjZjgtNTQxMGQ1MzdlYjlmPC9ETGlldT48L1RUaW4+PFRUaW4+PFRUcnVvbmc+SXNUYXhSZWR1Y3Rpb248L1RUcnVvbmc+PEtETGlldT5udW1lcmljPC9LRExpZXU+PERMaWV1PkZhbHNlPC9ETGlldT48L1RUaW4+PFRUaW4+PFRUcnVvbmc+SXNUYXhSZWR1Y3Rpb240MzwvVFRydW9uZz48S0RMaWV1Pm51bWVyaWM8L0tETGlldT48RExpZXU+RmFsc2U8L0RMaWV1PjwvVFRpbj48VFRpbj48VFRydW9uZz5Pcmdhbml6YXRpb25Vbml0SUQ8L1RUcnVvbmc+PEtETGlldT5zdHJpbmc8L0tETGlldT48RExpZXU+ZmU1YjBhM2EtYjkzOS0xMWViLWI5ODktMDA1MDU2YjIxOWZiPC9ETGlldT48L1RUaW4+PFRUaW4+PFRUcnVvbmc+T3JnYW5pemF0aW9uVW5pdE5hbWU8L1RUcnVvbmc+PEtETGlldT5zdHJpbmc8L0tETGlldT48RExpZXU+Q8OUTkcgVFkgVE5ISCBQSMav4buaQyBUUsOCTSBQSMOaIFFV4buQQzwvRExpZXU+PC9UVGluPjxUVGluPjxUVHJ1b25nPlJlZklEPC9UVHJ1b25nPjxLRExpZXU+c3RyaW5nPC9LRExpZXU+PERMaWV1PjQ0MzExMmI0LWMwYzEtNDI4NS04MmQyLTdkYTg5NGZmMWYyODwvRExpZXU+PC9UVGluPjxUVGluPjxUVHJ1b25nPkFtb3VudERlY2ltYWxEaWdpdHM8L1RUcnVvbmc+PEtETGlldT5zdHJpbmc8L0tETGlldT48RExpZXU+MDwvRExpZXU+PC9UVGluPjxUVGluPjxUVHJ1b25nPkFtb3VudE9DRGVjaW1hbERpZ2l0czwvVFRydW9uZz48S0RMaWV1PnN0cmluZzwvS0RMaWV1PjxETGlldT4yPC9ETGlldT48L1RUaW4+PFRUaW4+PFRUcnVvbmc+Q29lZmZpY2llbnREZWNpbWFsRGlnaXRzPC9UVHJ1b25nPjxLRExpZXU+c3RyaW5nPC9LRExpZXU+PERMaWV1PjI8L0RMaWV1PjwvVFRpbj48VFRpbj48VFRydW9uZz5FeGNoYW5nUmF0ZURlY2ltYWxEaWdpdHM8L1RUcnVvbmc+PEtETGlldT5zdHJpbmc8L0tETGlldT48RExpZXU+MjwvRExpZXU+PC9UVGluPjxUVGluPjxUVHJ1b25nPk1haW5DdXJyZW5jeTwvVFRydW9uZz48S0RMaWV1PnN0cmluZzwvS0RMaWV1PjxETGlldT5WTkQ8L0RMaWV1PjwvVFRpbj48VFRpbj48VFRydW9uZz5RdWFudGl0eURlY2ltYWxEaWdpdHM8L1RUcnVvbmc+PEtETGlldT5zdHJpbmc8L0tETGlldT48RExpZXU+NTwvRExpZXU+PC9UVGluPjxUVGluPjxUVHJ1b25nPlVuaXRQcmljZURlY2ltYWxEaWdpdHM8L1RUcnVvbmc+PEtETGlldT5zdHJpbmc8L0tETGlldT48RExpZXU+MDwvRExpZXU+PC9UVGluPjxUVGluPjxUVHJ1b25nPlVuaXRQcmljZU9DRGVjaW1hbERpZ2l0czwvVFRydW9uZz48S0RMaWV1PnN0cmluZzwvS0RMaWV1PjxETGlldT4wPC9ETGlldT48L1RUaW4+PFRUaW4+PFRUcnVvbmc+QXBwSUQ8L1RUcnVvbmc+PEtETGlldT5zdHJpbmc8L0tETGlldT48RExpZXU+M0ExMzYwNTEtODFFMi00MzcyLUJGQzctNUM2QzEyQjczMTU5PC9ETGlldT48L1RUaW4+PFRUaW4+PFRUcnVvbmc+VHJhbnNhY3Rpb25JRDwvVFRydW9uZz48S0RMaWV1PnN0cmluZzwvS0RMaWV1PjxETGlldT5ORENFSDFRTTBWVl88L0RMaWV1PjwvVFRpbj48L1RUS2hhYz48L0RMSERvbj48TUNDUVQ+TTEtMjQtbmFBU0ctMDAwMDAxMjAzNjg8L01DQ1FUPjxETFFSQ29kZT4wMDAyMDE5OTk5MDAzNlBGVzRWWVEzVjFWT0s1SkdMNVUzNUoxV05EQ0VIMVFNMFZWXzAxMTMwMTAxMjQzMTUwOTk2MDIwMTEwMzA2QzI0TUVTMDQwMTcwNTA4MjAyNDA0MjUwNjA2MzMwMDAwNjMwNDUzQzE8L0RMUVJDb2RlPjxEU0NLUz48TkJhbj48L05CYW4+PC9EU0NLUz48L0hEb24+
 */